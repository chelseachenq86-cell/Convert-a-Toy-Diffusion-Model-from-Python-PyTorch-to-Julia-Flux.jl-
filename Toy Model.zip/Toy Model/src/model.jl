using Flux, CUDA, LinearAlgebra, Statistics

# Basic functions used by all models
abstract type ModelMixin end

function gelu(x)
    return 0.5 * x .* (1 .+ tanh.(sqrt(2 / π) .* (x .+ 0.044715 .* x .^ 3)))
end

function get_sigma_embeds(batches::Int, sigma::AbstractArray{T}; 
                         scaling_factor::Float32=0.5f0, log_scale::Bool=true) where T
    if length(size(sigma)) == 0
        sigma = fill(sigma[], batches)
    else
        @assert size(sigma) == (batches,) "sigma.shape == [] or [batches]!"
    end
    
    if log_scale
        sigma = log.(sigma)
    end
    
    s = sigma .* scaling_factor
    return vcat(sin.(s), cos.(s))
end

function rand_input(model::ModelMixin, batchsize::Int)
    @assert isdefined(model, :input_dims) "Model must have 'input_dims' attribute!"
    return randn(Float32, model.input_dims..., batchsize)
end

# Currently predicts eps, override following methods to predict, for example, x0
function get_loss(model::ModelMixin, x0, sigma, eps; cond=nothing, loss=Flux.mse)
    return loss(eps, model(x0 .+ sigma .* eps, sigma; cond=cond))
end

function predict_eps(model::ModelMixin, x, sigma; cond=nothing)
    return model(x, sigma; cond=cond)
end

function predict_eps_cfg(model::ModelMixin, x, sigma, cond, cfg_scale)
    if isnothing(cond) || cfg_scale == 0
        return predict_eps(model, x, sigma; cond=cond)
    end
    @assert length(size(sigma)) == 0 "CFG sampling only supports singleton sigma!"
    
    uncond = fill(model.cond_embed.null_cond, size(cond))
    x_cat = cat(x, x, dims=ndims(x))
    cond_cat = cat(cond, uncond, dims=ndims(cond))
    
    eps_all = predict_eps(model, x_cat, sigma; cond=cond_cat)
    eps_cond, eps_uncond = eps_all[:, 1:size(x,2)], eps_all[:, size(x,2)+1:end]
    
    return eps_cond .+ cfg_scale .* (eps_cond .- eps_uncond)
end

# A simple embedding that works just as well as usual sinusoidal embedding
struct SigmaEmbedderSinCos
    mlp::Chain
    scaling_factor::Float32
    log_scale::Bool
    
    function SigmaEmbedderSinCos(hidden_size::Int; 
                                scaling_factor::Float32=0.5f0, 
                                log_scale::Bool=true)
        mlp = Chain(
            Dense(2, hidden_size),
            SiLU(),
            Dense(hidden_size, hidden_size)
        )
        new(mlp, scaling_factor, log_scale)
    end
end

function (m::SigmaEmbedderSinCos)(batches::Int, sigma)
    sig_embed = get_sigma_embeds(batches, sigma;
                                scaling_factor=m.scaling_factor,
                                log_scale=m.log_scale)
    return m.mlp(sig_embed)
end

# Modifiers for models
function alpha(sigma)
    return 1 ./ (1 .+ sigma.^2)
end

# Scale model input so that its norm stays constant for all sigma
function scaled_forward(model::ModelMixin, x, sigma; cond=nothing)
    return model(x .* sqrt.(alpha(sigma)), sigma; cond=cond)
end

# Train model to predict x0 instead of eps
function pred_x0_get_loss(model::ModelMixin, x0, sigma, eps; cond=nothing, loss=Flux.mse)
    return loss(x0, model(x0 .+ sigma .* eps, sigma; cond=cond))
end

function pred_x0_predict_eps(model::ModelMixin, x, sigma; cond=nothing)
    x0_hat = model(x, sigma; cond=cond)
    return (x .- x0_hat) ./ sigma
end

# Train model to predict v instead of eps
function pred_v_get_loss(model::ModelMixin, x0, sigma, eps; cond=nothing, loss=Flux.mse)
    xt = x0 .+ sigma .* eps
    v = sqrt.(alpha(sigma)) .* eps .- sqrt.(1 .- alpha(sigma)) .* x0
    return loss(v, model(xt, sigma; cond=cond))
end

function pred_v_predict_eps(model::ModelMixin, x, sigma; cond=nothing)
    v_hat = model(x, sigma; cond=cond)
    return sqrt.(alpha(sigma)) .* (v_hat .+ sqrt.(1 .- alpha(sigma)) .* x)
end

# Common functions for other models
struct CondSequential
    layers::Vector{Any}
end

function (m::CondSequential)(x, cond)
    for layer in m.layers
        x = layer(x, cond)
    end
    return x
end

struct Attention
    num_heads::Int
    head_dim::Int
    qkv::Dense
    proj::Dense
    
    function Attention(head_dim::Int; num_heads::Int=8, qkv_bias::Bool=false)
        dim = head_dim * num_heads
        new(num_heads, head_dim,
            Dense(dim, dim * 3, bias=qkv_bias),
            Dense(dim, dim))
    end
end

function (m::Attention)(x)
    # x shape: (D, N, B) where D = num_heads * head_dim
    batch_size = size(x, 3)
    seq_len = size(x, 2)
    
    # QKV projection
    qkv = m.qkv(x)  # (3D, N, B)
    qkv = reshape(qkv, 3, m.num_heads, m.head_dim, seq_len, batch_size)
    
    # Split into q, k, v
    q, k, v = eachslice(qkv, dims=1)  # Each (H, K, N, B)
    
    # Scaled dot-product attention
    scale = Float32(1 / sqrt(m.head_dim))
    attention = softmax((@view(q[:,:,:,:]) ⊡ (@view(k[:,:,:,:]) |> transpose) .* scale), dims=2)
    
    # Apply attention to values
    out = attention ⊠ v
    out = reshape(out, :, seq_len, batch_size)
    
    return m.proj(out)
end

# Embedding table for conditioning on labels
struct CondEmbedderLabel
    embeddings::Embedding
    null_cond::Int
    dropout_prob::Float32
    
    function CondEmbedderLabel(hidden_size::Int, num_classes::Int; 
                              dropout_prob::Float32=0.1f0)
        new(Embedding(num_classes + 1 => hidden_size),
            num_classes,
            dropout_prob)
    end
end

function (m::CondEmbedderLabel)(labels)
    if Flux.training
        drop_mask = rand(Float32, size(labels)) .< m.dropout_prob
        labels = ifelse.(drop_mask, m.null_cond, labels)
    end
    return m.embeddings(labels)
end

# Simple MLP for toy examples
struct TimeInputMLP <: ModelMixin
    net::Chain
    input_dims::Tuple
    
    function TimeInputMLP(dim::Int=2, hidden_dims::Tuple=(16,128,256,128,16))
        layers = []
        dims = (dim + 2, hidden_dims...)
        for i in 1:length(dims)-1
            push!(layers, Dense(dims[i], dims[i+1]))
            push!(layers, gelu())
        end
        push!(layers, Dense(dims[end], dim))
        new(Chain(layers...), (dim,))
    end
end

function (m::TimeInputMLP)(x, sigma; cond=nothing)
    # x shape: (dim, batch)
    # sigma shape: (batch,) or scalar
    batchsize = size(x, ndims(x))
    sigma_embeds = get_sigma_embeds(batchsize, sigma)  # shape: (2, batch)
    nn_input = vcat(x, sigma_embeds)                   # shape: (dim+2, batch)
    return m.net(nn_input)
end

# Ideal denoiser defined by a dataset
function sq_norm(M, k)
    # M: (n, b) --(norm)--> (b,) --(repeat)--> (k, b)
    return repeat(sum(abs2, M, dims=1), outer=(k, 1))
end

struct IdealDenoiser <: ModelMixin
    data::Matrix{Float32}
    input_dims::Tuple
    
    function IdealDenoiser(dataset)
        data = hcat([dataset[i] for i in 1:length(dataset)]...)
        new(data, size(data)[1:end-1])
    end
end

function (m::IdealDenoiser)(x, sigma; cond=nothing)
    data = m.data |> gpu
    x_flat = reshape(x, :, size(x)[end])
    d_flat = reshape(data, :, size(data)[end])
    
    xb = size(x_flat, 2)
    db = size(d_flat, 2)
    @assert size(x_flat, 1) == size(d_flat, 1) "Input x must have same dimension as data!"
    @assert length(size(sigma)) == 0 || size(sigma, 1) == xb "sigma must be singleton or have same batch dimension as x!"
    
    # sq_diffs: ||x - x0||^2
    sq_diffs = sq_norm(x_flat, db)' .+ sq_norm(d_flat, xb) .- 2 .* (d_flat' ⊠ x_flat)
    weights = softmax(-sq_diffs ./ (2 .* sigma.^2), dims=1)
    eps = reshape(weights' ⊠ data, size(x))
    
    return (x .- eps) ./ sigma
end
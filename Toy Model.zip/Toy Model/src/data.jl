using CSV
using DataFrames
using LinearAlgebra
using Flux
using Flux: DataLoader
using Random
using CUDA
using CUDA: allowscalar

# Function to determine if CUDA is available
const CUDA_AVAILABLE = CUDA.functional()

# Helper function to move data to GPU if available
function maybe_cuda(x)
    CUDA_AVAILABLE ? CUDA.cu(x) : x
end

# Abstract type for datasets
abstract type AbstractDataset end

# Swissroll dataset
struct Swissroll <: AbstractDataset
    vals::Matrix{Float32}  # Change to Float32
    
    function Swissroll(tmin::Real, tmax::Real, N::Int; center::Tuple{Real,Real}=(0,0), scale::Real=1.0)
        t = tmin .+ range(0, 1, length=N) .* tmax
        center_vec = reshape(collect(Float32.(center)), 1, 2)  # Convert to Float32
        vals = center_vec .+ scale .* vcat(
            (t .* cos.(t) ./ tmax)',
            (t .* sin.(t) ./ tmax)'
        )'
        new(Float32.(vals))  # Convert to Float32
    end
end

Base.length(ds::Swissroll) = size(ds.vals, 1)
Base.getindex(ds::Swissroll, i) = ds.vals[i, :]  # Allow vector indexing

# DatasaurusDozen dataset
struct DatasaurusDozen <: AbstractDataset
    points::Matrix{Float32}  # Change to Float32
    enlarge_factor::Int
    
    function DatasaurusDozen(csv_file::String, dataset::String; 
                            enlarge_factor::Int=15, delimiter::Char='\t',
                            scale::Real=50, offset::Real=50)
        df = CSV.read(csv_file, DataFrame, delim=delimiter)
        points = filter(row -> row[1] == dataset, df)
        if isempty(points)
            error("Dataset $dataset not found in CSV file")
        end
        
        # Convert points to matrix and apply scaling/offset
        point_matrix = Matrix{Float32}(points[:, 2:end])  # Convert to Float32
        point_matrix = (point_matrix .- offset) ./ scale
        
        # Replicate data if enlarge_factor > 1
        if enlarge_factor > 1
            point_matrix = repeat(point_matrix, enlarge_factor, 1)
        end
        
        new(point_matrix, enlarge_factor)
    end
end

Base.length(ds::DatasaurusDozen) = size(ds.points, 1)
Base.getindex(ds::DatasaurusDozen, i) = ds.points[i, :]  # Allow vector indexing

# MappedDataset
struct MappedDataset{T<:AbstractDataset, F} <: AbstractDataset
    dataset::T
    fn::F
end

Base.length(ds::MappedDataset) = length(ds.dataset)
Base.getindex(ds::MappedDataset, i) = ds.fn(ds.dataset[i])

# Image transformation utilities
function img_train_transform(img)
    # Note: This is a simplified version. In practice, you'd want to use image processing libraries
    # like Images.jl for proper image transformations
    if rand() > 0.5
        img = reverse(img, dims=2)  # horizontal flip
    end
    transformed = 2.0f0 .* img .- 1.0f0  # Convert to Float32 for better GPU compatibility
    return maybe_cuda(transformed)
end

function img_normalize(x)
    normalized = clamp.((x .+ 1.0f0) ./ 2.0f0, 0.0f0, 1.0f0)  # Use Float32
    return maybe_cuda(normalized)
end

# DataLoader creation utilities
function create_dataloader(dataset::AbstractDataset; 
                         batch_size::Int=32, 
                         shuffle::Bool=true,
                         use_cuda::Bool=CUDA_AVAILABLE,
                         suppress_warnings::Bool=false)
    # Calculate appropriate batch size
    n_samples = length(dataset)
    actual_batch_size = min(batch_size, n_samples)
    
    # Print informative message if batch size was adjusted
    if actual_batch_size < batch_size && !suppress_warnings
        @info "Dataset size ($n_samples) is smaller than requested batch size ($batch_size). Using batch size of $actual_batch_size."
    end
    
    # First collect all data points
    if dataset isa Union{Swissroll, DatasaurusDozen}
        # For these datasets, we can directly use the matrix
        data_matrix = dataset isa Swissroll ? dataset.vals : dataset.points
    else
        # For other datasets, collect points into matrix
        data_points = [dataset[i] for i in 1:n_samples]
        data_matrix = reduce(hcat, data_points)'
    end
    
    # Move to GPU if requested and available
    if use_cuda && CUDA_AVAILABLE
        data_matrix = CUDA.cu(data_matrix)
    end
    
    # Create DataLoader with the matrix
    return DataLoader(data_matrix; 
                     batchsize=actual_batch_size, 
                     shuffle=shuffle,
                     partial=true)  # Allow partial batches
end

# Usage functions with CUDA support
function create_swissroll_loader(tmin::Real, tmax::Real, N::Int;
                               batch_size::Int=32,
                               shuffle::Bool=true,
                               use_cuda::Bool=CUDA_AVAILABLE,
                               suppress_warnings::Bool=false,
                               kwargs...)
    dataset = Swissroll(tmin, tmax, N; kwargs...)
    return create_dataloader(dataset; 
                           batch_size=batch_size, 
                           shuffle=shuffle,
                           use_cuda=use_cuda,
                           suppress_warnings=suppress_warnings)
end

function create_datasaurus_loader(csv_file::String, dataset::String;
                                batch_size::Int=32,
                                shuffle::Bool=true,
                                use_cuda::Bool=CUDA_AVAILABLE,
                                suppress_warnings::Bool=false,
                                kwargs...)
    dataset = DatasaurusDozen(csv_file, dataset; kwargs...)
    return create_dataloader(dataset; 
                           batch_size=batch_size, 
                           shuffle=shuffle,
                           use_cuda=use_cuda,
                           suppress_warnings=suppress_warnings)
end

# Helper function to create a mapped dataloader with CUDA support
function create_mapped_loader(dataset::AbstractDataset, fn::Function;
                            batch_size::Int=32,
                            shuffle::Bool=true,
                            use_cuda::Bool=CUDA_AVAILABLE,
                            suppress_warnings::Bool=false)
    mapped_dataset = MappedDataset(dataset, fn)
    return create_dataloader(mapped_dataset; 
                           batch_size=batch_size, 
                           shuffle=shuffle,
                           use_cuda=use_cuda,
                           suppress_warnings=suppress_warnings)
end
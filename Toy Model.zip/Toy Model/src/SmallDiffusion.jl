module SmallDiffusion

using Flux
using Statistics
using Random
using LinearAlgebra
using CUDA
using CSV
using DataFrames

include("data.jl")
include("model.jl")
include("diffusion.jl")

# Export all the public interface
export 
    # From data.jl
    Swissroll, DatasaurusDozen, MappedDataset,
    create_swissroll_loader, create_datasaurus_loader, create_mapped_loader,
    img_normalize, img_train_transform, create_dataloader,
    maybe_cuda,

    # From model.jl
    ModelMixin, TimeInputMLP, IdealDenoiser,
    get_loss, predict_eps, predict_eps_cfg, rand_input,
    CondSequential, Attention, CondEmbedderLabel,
    alpha, scaled_forward, pred_x0_get_loss, pred_x0_predict_eps,
    pred_v_get_loss, pred_v_predict_eps, get_sigma_embeds,

    # From diffusion.jl
    # Types
    Schedule, BaseSchedule, 
    ScheduleLogLinear, ScheduleDDPM, ScheduleLDM, 
    ScheduleSigmoid, ScheduleCosine,
    # Functions
    sample_sigmas, sample_batch, sigmas_from_betas,
    generate_train_sample, training_loop, samples

end # module
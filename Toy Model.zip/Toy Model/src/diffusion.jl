using Flux
using CUDA
using ProgressMeter
using LinearAlgebra
using Statistics
using Random

# Helper functions
sigmoid(x) = 1 / (1 + exp(-x))

# Diffusion noise schedules parameterized by sigma
abstract type Schedule end

struct BaseSchedule <: Schedule
    sigmas::Vector{Float32}
end

Base.getindex(s::Schedule, i) = s.sigmas[i]
Base.length(s::Schedule) = length(s.sigmas)

function sample_sigmas(schedule::Schedule, steps::Int)
    """Called during sampling to get a decreasing sigma schedule with a
    specified number of sampling steps:
      - Spacing is "trailing" as in Table 2 of https://arxiv.org/abs/2305.08891
      - Includes initial and final sigmas
        i.e. length(schedule.sample_sigmas(steps)) == steps + 1
    """
    indices = round.(Int, length(schedule) .* (1 .- range(0, steps-1)/steps)) .- 1
    return schedule[vcat(indices, [0])]
end

function sample_batch(schedule::Schedule, x0)
    """Called during training to get a batch of randomly sampled sigma values
    """
    batchsize = size(x0)[end]
    device = x0 isa CuArray ? gpu : cpu
    return device(schedule[rand(1:length(schedule), batchsize)])
end

function sigmas_from_betas(betas::AbstractArray{<:AbstractFloat})
    return sqrt.((1 ./ cumprod(1.0f0 .- betas)) .- 1)
end

# Simple log-linear schedule works for training many diffusion models
mutable struct ScheduleLogLinear <: Schedule
    sigmas::Vector{Float32}
    
    function ScheduleLogLinear(N::Int; sigma_min::Float32=0.02f0, sigma_max::Float32=10.0f0)
        new(Float32.(10 .^ range(log10(sigma_min), log10(sigma_max), N)))
    end
end

# Default parameters recover schedule used in most diffusion models
mutable struct ScheduleDDPM <: Schedule
    sigmas::Vector{Float32}
    
    function ScheduleDDPM(N::Int=1000; beta_start::Float32=0.0001f0, beta_end::Float32=0.02f0)
        betas = range(beta_start, beta_end, N)
        new(sigmas_from_betas(betas))
    end
end

# Default parameters recover schedule used in most latent diffusion models
mutable struct ScheduleLDM <: Schedule
    sigmas::Vector{Float32}
    
    function ScheduleLDM(N::Int=1000; beta_start::Float32=0.00085f0, beta_end::Float32=0.012f0)
        betas = range(sqrt(beta_start), sqrt(beta_end), N) .^ 2
        new(sigmas_from_betas(betas))
    end
end

# Sigmoid schedule used in GeoDiff
mutable struct ScheduleSigmoid <: Schedule
    sigmas::Vector{Float32}
    
    function ScheduleSigmoid(N::Int=1000; beta_start::Float32=0.0001f0, beta_end::Float32=0.02f0)
        t = range(-6, 6, N)
        betas = @. sigmoid(t) * (beta_end - beta_start) + beta_start
        new(sigmas_from_betas(betas))
    end
end

# Cosine schedule used in Nichol and Dhariwal 2021
mutable struct ScheduleCosine <: Schedule
    sigmas::Vector{Float32}
    
    function ScheduleCosine(N::Int=1000; beta_start::Float32=0.0001f0, beta_end::Float32=0.02f0, max_beta::Float32=0.999f0)
        alpha_bar(t) = cos((t + 0.008f0) / 1.008f0 * π / 2)^2
        betas = [min(1 - alpha_bar((i+1)/N)/alpha_bar(i/N), max_beta) for i in 0:N-1]
        new(sigmas_from_betas(Float32.(betas)))
    end
end

# Generate training samples
function generate_train_sample(x0, schedule::Schedule, conditional::Bool=false)
    """Given a batch of data
    x0: Either a data tensor or a tuple of (data, labels)
    Returns
    eps: i.i.d. normal with same shape as x0
    sigma: uniformly sampled from schedule, with shape Bx1x..x1 for broadcasting
    """
    cond = conditional ? x0[2] : nothing
    x0_data = conditional ? x0[1] : x0
    sigma = sample_batch(schedule, x0_data)
    
    # Add dimensions for broadcasting using reshape
    sigma_size = ones(Int, ndims(x0_data))
    sigma_size[end] = size(sigma, 1)
    sigma = reshape(sigma, sigma_size...)
    
    eps = randn(eltype(x0_data), size(x0_data))
    if x0_data isa CuArray
        eps = maybe_cuda(eps)
    end
    
    return x0_data, sigma, eps, cond
end

# Training loop that returns a vector of training states
function training_loop(loader, model, schedule::Schedule; 
                      accelerator=nothing, epochs::Int=10000, 
                      lr::Float32=1f-3, conditional::Bool=false)
    opt = Flux.setup(Adam(lr), model)
    training_states = []
    
    @showprogress for epoch in 1:epochs
        for x0 in loader
            # Training mode
            Flux.trainmode!(model)
            
            # Generate training sample
            x0_data, sigma, eps, cond = generate_train_sample(x0, schedule, conditional)
            
            # Compute loss and gradients
            loss, grads = Flux.withgradient(model) do m
                get_loss(m, x0_data, sigma, eps; cond=cond)
            end
            
            # Update parameters
            Flux.update!(opt, model, grads[1])
            
            # Store training state
            push!(training_states, (
                model=deepcopy(model), 
                optimizer=deepcopy(opt), 
                loader=loader, 
                loss=loss, 
                x0=x0_data, 
                sigma=sigma, 
                eps=eps, 
                cond=cond
            ))
        end
    end
    
    return training_states
end

# Sampling function that returns a vector of intermediate states
function samples(model, sigmas::AbstractVector{<:AbstractFloat};
                gam::Float32=1f0, mu::Float32=0f0, cfg_scale::Float32=0f0,
                batchsize::Int=1, xt=nothing, cond=nothing, accelerator=nothing)
    """Generalizes most commonly-used samplers:
    DDPM       : gam=1, mu=0.5
    DDIM       : gam=1, mu=0
    Accelerated: gam=2, mu=0
    """
    # Evaluation mode
    Flux.testmode!(model)
    
    # Initialize xt if not provided
    if isnothing(xt)
        xt = rand_input(model, batchsize) .* sigmas[1]
        xt = xt isa CuArray ? xt : maybe_cuda(xt)
    end
    
    # Move condition to same device as xt if provided
    if !isnothing(cond)
        @assert size(cond)[end] == size(xt)[end] "cond must have same batch size as x!"
        cond = cond isa CuArray ? cond : maybe_cuda(cond)
    end
    
    # Move sigmas to the same device as xt
    device_sigmas = xt isa CuArray ? maybe_cuda(sigmas) : sigmas
    
    sample_states = [xt]
    eps = nothing
    
    for i in 1:length(device_sigmas)-1
        # Use array slicing instead of scalar indexing
        sig = @view(device_sigmas[i:i])
        sig_prev = @view(device_sigmas[(i+1):(i+1)])
        
        eps_prev = eps
        eps = predict_eps_cfg(model, xt, sig[1], cond, cfg_scale)
        
        # Compute average eps
        eps_av = i > 1 ? eps .* gam .+ eps_prev .* (1-gam) : eps
        
        # Update xt using broadcasting
        sig_p = (sig_prev[1]/sig[1]^mu)^(1/(1-mu))  # sig_prev == sig^mu * sig_p^(1-mu)
        eta = sqrt(sig_prev[1]^2 - sig_p^2)
        xt = xt .- (sig[1] - sig_p) .* eps_av .+ eta .* rand_input(model, size(xt)[end])
        
        push!(sample_states, xt)
    end
    
    return sample_states
end 